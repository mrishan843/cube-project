Wish i had more time because i got this assignment at a very unfortunate timing. but i did what could in 2 days. I hope you consider that.
